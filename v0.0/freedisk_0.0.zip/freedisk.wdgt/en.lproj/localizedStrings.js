var localizedStrings = new Object;

localizedStrings["Hello, World!"] = 'Free Disk';
localizedStrings["Done"] = "Done";
