var localizedStrings = new Object;

localizedStrings["Hello, World!"] = 'FreeDiskO';
localizedStrings["Done"] = "Done";
localizedStrings['v0.1'] = 'v0.3';
